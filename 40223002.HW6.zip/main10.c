//مهرسا احمدی 40223002 

#include <stdio.h>
#include <math.h>

void solver( float a, float b, float c, float *p1, float *p2 );


int main ()
{
    float a, b, c;
    double delta;
    int number;
   
    printf(" Enter values for a, b and c : \n");
    scanf("%f%f%f", &a,&b,&c);
    delta = ( b * b ) - ( 4 * a * c);
    float x1,x2;
    float *p1 = &x1;
    float *p2 = &x2;

    if ( delta < 0 || (a < 0 && b <0 ))
    printf(" This equation has no real roots. \n");

    else if ( delta == 0 )
    {
      solver(a,b,c,p1,p2);
      number = 1;
      printf(" The second two degree equation has %d answers \n", number);
      printf(" The answer is : %f \n", *p1);
    }

    else if ( delta > 0 )
    {
      solver(a,b,c,p1,p2);
      number = 2;
      printf(" The second two degree equation has %d answers \n", number);
      printf(" The answers are : %f and % f\n ", *p1, *p2);
    }   

return 0;
}



  void solver( float a, float b, float c, float *p1, float *p2)
  {
    double delta;

    delta = (b*b) - (4*a*c);
    
    if ( delta == 0 )
    {
      *p1=*p2;
      *p2= (-b) / (2 * a);
    }

    else if ( delta > 0 )
    {
      *p1 = ((-b+sqrt(delta))/(2*a));
      *p2 = ((-b-sqrt(delta))/(2*a));
    }  
  }

